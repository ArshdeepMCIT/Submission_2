import java.io.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;

public class OpcodeExport extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length < 1) {
            println("ERROR: Missing output file argument");
            return;
        }

        File outFile = new File(args[0]);
        File parent = outFile.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();

        Listing listing = currentProgram.getListing();
        InstructionIterator it = listing.getInstructions(true);

        long count = 0;
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outFile))) {
            while (it.hasNext() && !monitor.isCancelled()) {
                Instruction ins = it.next();
                String mnem = ins.getMnemonicString();
                if (mnem != null && !mnem.isEmpty()) {
                    bw.write(mnem);
                    bw.newLine();
                    count++;
                }
            }
        }

        println("WROTE_OPCODES=" + count + " FILE=" + outFile.getAbsolutePath());
    }
}
