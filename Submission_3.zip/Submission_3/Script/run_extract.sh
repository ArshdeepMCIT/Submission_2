#!/bin/bash
set -u

INPUT_LIST="/root/Submission_3/Script/input_files.txt"
OUT_DIR="/root/Submission_3/Raw_Extracted_Files"
LOG_DIR="/root/Submission_3/Script/logs"

GHIDRA_HEADLESS="/root/Downloads/ghidra_12.0.3_PUBLIC_20260210/ghidra_12.0.3_PUBLIC/support/analyzeHeadless"
SCRIPT_PATH="/root/Submission_3/Script"
POST_SCRIPT="OpcodeExport.java"

mkdir -p "$OUT_DIR" "$LOG_DIR" "/root/Submission_3/ghidra_projects"

TS=$(date +"%Y-%m-%d_%H%M%S")
LOGFILE="$LOG_DIR/run_$TS.log"

echo "=== Submission 3 Opcode Extraction Run ===" | tee "$LOGFILE"
echo "INPUT_LIST=$INPUT_LIST" | tee -a "$LOGFILE"
echo "OUT_DIR=$OUT_DIR" | tee -a "$LOGFILE"
echo "GHIDRA_HEADLESS=$GHIDRA_HEADLESS" | tee -a "$LOGFILE"
echo "SCRIPT_PATH=$SCRIPT_PATH" | tee -a "$LOGFILE"
echo "POST_SCRIPT=$POST_SCRIPT" | tee -a "$LOGFILE"
echo "TIME=$TS" | tee -a "$LOGFILE"
echo "-----------------------------------------" | tee -a "$LOGFILE"

i=0
ok=0
fail=0

while IFS= read -r f; do
  i=$((i+1))
  base=$(basename "$f")
  out="$OUT_DIR/${base}.opcode"

  proj_loc="/root/Submission_3/ghidra_projects"
  proj_name="proj_$i"

  echo "[#${i}] Processing: $f" | tee -a "$LOGFILE"

  if [[ ! -f "$f" ]]; then
    echo "  FAIL: file not found" | tee -a "$LOGFILE"
    fail=$((fail+1))
    echo "" | tee -a "$LOGFILE"
    continue
  fi

  "$GHIDRA_HEADLESS" "$proj_loc" "$proj_name" \
    -import "$f" \
    -analysisTimeoutPerFile 300 \
    -scriptPath "$SCRIPT_PATH" \
    -postScript "$POST_SCRIPT" "$out" \
    -deleteProject \
    >> "$LOGFILE" 2>&1

  if [[ -s "$out" ]]; then
    lines=$(wc -l < "$out" | tr -d ' ')
    echo "  OK: wrote $lines opcodes -> $out" | tee -a "$LOGFILE"
    ok=$((ok+1))
  else
    echo "  FAIL: output missing/empty -> $out" | tee -a "$LOGFILE"
    fail=$((fail+1))
  fi

  echo "" | tee -a "$LOGFILE"
done < "$INPUT_LIST"

echo "=== DONE === OK=$ok FAIL=$fail TOTAL=$i" | tee -a "$LOGFILE"
